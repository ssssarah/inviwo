description of the LabStreamlines module
