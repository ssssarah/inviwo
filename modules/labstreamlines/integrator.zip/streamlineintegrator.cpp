/*********************************************************************
 *  Author  : Himangshu Saikia
 *  Init    : Tuesday, September 19, 2017 - 15:08:33
 *
 *  Project : KTH Inviwo Modules
 *
 *  License : Follows the Inviwo BSD license model
 *********************************************************************
 */

#include <labstreamlines/streamlineintegrator.h>
#include <labstreamlines/integrator.h>
#include <inviwo/core/util/utilities.h>
#include <inviwo/core/interaction/events/mouseevent.h>
//#include <math.h> /* pow */


namespace inviwo {

// The Class Identifier has to be globally unique. Use a reverse DNS naming scheme
const ProcessorInfo StreamlineIntegrator::processorInfo_{
    "org.inviwo.StreamlineIntegrator",  // Class identifier
    "Streamline Integrator",            // Display name
    "KTH Lab",                          // Category
    CodeState::Experimental,            // Code state
    Tags::None,                         // Tags
};



const ProcessorInfo StreamlineIntegrator::getProcessorInfo() const { return processorInfo_; }

StreamlineIntegrator::StreamlineIntegrator()
    : Processor()
    , inData("volIn")
    , outMesh("meshOut")
    , propStartPoint("startPoint", "Start Point", vec2(0.5, 0.5), vec2(0), vec2(1024), vec2(0.5))
    , propSeedMode("seedMode", "Seeds")
    // TODO: Initialize additional properties
    // propertyName("propertyIdentifier", "Display Name of the Propery",
    // default value (optional), minimum value (optional), maximum value (optional), increment
    // (optional)); propertyIdentifier cannot have spaces
    , propIsBackword("isBackword", "Backword")
    , propStopAtZero("stopAtZero", "Stop at zero")
    , propStepLength("stepLength", "Step Length")
    , propStopAtBoundary("stopAtBoundary", "Stop at boundary")
    , propSamplesNumber("samplesNumber", "Samples Number", 1, 1, 200, 1)
    , propGridPointsX("gridPointsX", "Grid points X", 1, 1, 200, 1)
    , propGridPointsY("gridPointsY", "Grid points Y", 1, 1, 200, 1)
    , propVelocity("velocity", "Velocity")
    , propMaxArcLength("maxArcLength", "Max arc length")
    , propNumberOfPoints("numberOfPoints", "Number of Points", 1, 1, 200, 1)
    , mouseMoveStart("mouseMoveStart", "Move Start", [this](Event* e) { eventMoveStart(e); },
                     MouseButton::Left, MouseState::Press | MouseState::Move) {
    // Register Ports
    addPort(inData);
    addPort(outMesh);

    // Register Properties
    propSeedMode.addOption("one", "Single Start Point", 0);
    propSeedMode.addOption("multiple", "Multiple Seeds", 1);
    addProperty(propSeedMode);
    addProperty(propStartPoint);
    addProperty(mouseMoveStart);

    // TODO: Register additional properties
    // addProperty(propertyName);

    addProperty(propIsBackword);
    addProperty(propGridPointsY);
    addProperty(propMaxArcLength);
    addProperty(propGridPointsX);
    addProperty(propNumberOfPoints);
    addProperty(propStopAtZero);
    addProperty(propStepLength);
    addProperty(propSamplesNumber);
    addProperty(propStopAtBoundary);
    addProperty(propVelocity);

	util::hide(propGridPointsX);
    util::hide(propGridPointsY);
    util::hide(propNumberOfPoints);

    // You can hide and show properties for a single seed and hide properties for multiple seeds
    // (TODO)
    propSeedMode.onChange([this]() {
        if (propSeedMode.get() == 0) {
            util::show(propStartPoint, mouseMoveStart);
            
            util::hide(propGridPointsX);
            util::hide(propGridPointsY);
            util::hide(propNumberOfPoints);
            // util::hide(...)
        } else {
            util::hide(propStartPoint, mouseMoveStart);
            util::show(propGridPointsX);
            util::show(propGridPointsY);
            util::show(propNumberOfPoints);

            // util::show(...)
        }
    });
}

void StreamlineIntegrator::eventMoveStart(Event* event) {
    // Handle mouse interaction only if we
    // are in the mode with a single point
    if (propSeedMode.get() == 1) return;
    auto mouseEvent = static_cast<MouseEvent*>(event);
    vec2 mousePos = mouseEvent->posNormalized();
    // Denormalize to volume dimensions
    mousePos.x *= dims.x - 1;
    mousePos.y *= dims.y - 1;
    // Update starting point
    propStartPoint.set(mousePos);
    event->markAsUsed();
}

void StreamlineIntegrator::process() {
    // Get input
    if (!inData.hasData()) {
        return;
    }
    auto vol = inData.getData();

    // Retreive data in a form that we can access it
    auto vr = vol->getRepresentation<VolumeRAM>();
    dims = vol->getDimensions();
    // The start point should be inside the volume (set maximum to the upper right corner)
    propStartPoint.setMaxValue(vec2(dims.x - 1, dims.y - 1));

    propStepLength.setMinValue(0);
    propStepLength.setMaxValue(dims.x - 1 + dims.y - 1);
    propVelocity.setMinValue(0);
    propVelocity.setMaxValue(dims.x - 1 + dims.y - 1 );

	propMaxArcLength.setMinValue(0);
    propMaxArcLength.setMaxValue(dims.x + dims.y);

    auto mesh = std::make_shared<BasicMesh>();
    std::vector<BasicMesh::Vertex> vertices;

    int integrationDirection = propIsBackword.get() == true ? -1 : 1;
    int samples = propSamplesNumber.get();
    float stepLength = propStepLength.get();
    boolean stopAtBoundary = propStopAtBoundary.get();
    boolean stopAtZero = propStopAtZero.get();
    int numberOfPoints = propNumberOfPoints.get();
    int minVelocity = propVelocity.get();

    if (propSeedMode.get() == 0) {
        auto indexBufferPoints = mesh->addIndexBuffer(DrawType::Points, ConnectivityType::None);
        auto indexBufferRK = mesh->addIndexBuffer(DrawType::Lines, ConnectivityType::Strip);

        // Draw start point
        vec2 startPoint = propStartPoint.get();

        LogProcessorInfo("Coord x0: " << startPoint.x << " y0 :" << startPoint.y);
        LogProcessorInfo("dims : " << dims.x << " y :" << dims.y);

        vertices.push_back({vec3(startPoint.x / (dims.x - 1), startPoint.y / (dims.y - 1), 0),
                            vec3(0), vec3(0), vec4(0, 0, 0, 1)});
        indexBufferPoints->add(static_cast<std::uint32_t>(0));
        indexBufferRK->add(static_cast<std::uint32_t>(0));

		float sum = 0;

        for (int i = 0; i < samples; i++) {
            vec2 vecField = Integrator::sampleFromField(vr, dims, startPoint);

            if (stopAtZero && vecField.x == 0 && vecField.y == 0) break;
            

            vec2 curr =
                Integrator::RK4(vr, dims, startPoint, stepLength, integrationDirection, vecField);

			float x1 = curr.x;
            float y1 = curr.y;

			float x2 = startPoint.x;
            float y2 = startPoint.y;
			float distancex = pow(x1-x2, 2);
            float distancey = pow(y1 - y2, 2); 
            if (minVelocity > sqrt(abs(distancex - distancey))) break;

			sum += sqrt(abs(distancex - distancey));

			if (sum > propMaxArcLength.get()) break;

            if (stopAtBoundary && (startPoint.x < 0 || startPoint.x > dims.x - 1 ||
                                   startPoint.y < 0 || startPoint.y > dims.y - 1))
                break;

            indexBufferRK->add(static_cast<std::uint32_t>(vertices.size()));
            indexBufferPoints->add(static_cast<std::uint32_t>(vertices.size()));
            vertices.push_back({vec3(startPoint.x / (dims.x - 1), startPoint.y / (dims.y - 1), 0),
                                vec3(0), vec3(0), vec4(0, 0.4f, 0.8f, 1)});

            // LogProcessorInfo("Coord x0: " << startPoint.x << " y0 :" << startPoint.y);
            // LogProcessorInfo("dims : " << dims.x << " y :" << dims.y);
            // Draw line between curr and startPoint

            startPoint = curr;
        }

        // TODO: Create one stream line from the given start point
    } else {

        auto indexBufferGrid = mesh->addIndexBuffer(DrawType::Lines, ConnectivityType::None);
		drawLineSegmentsByXandY(dims.x, dims.y, propGridPointsX.get(), propGridPointsY.get(), 
			indexBufferGrid, vertices);

        int bx = dims.x - 1;
        int by = dims.y - 1;
        int a = 0;
        vec2 vecField;
        for (int i = 0; i < numberOfPoints; i++) {
            float random = ((float)rand()) / (float)RAND_MAX;
            float diff = bx - a;
            float rx = random * diff;
            
			random = ((float)rand()) / (float)RAND_MAX;
            diff = bx - a; 
            float ry = random * diff;
			
			vec2 startPoint;
            startPoint[0] = rx; 
            startPoint[1] = ry; 
			
			auto indexBufferPoints = mesh->addIndexBuffer(DrawType::Points, ConnectivityType::None);
            auto indexBufferRK = mesh->addIndexBuffer(DrawType::Lines, ConnectivityType::Strip);

			vertices.push_back({vec3(startPoint.x / (dims.x - 1), startPoint.y / (dims.y - 1), 0),
                                vec3(0), vec3(0), vec4(0, 0.4f, 0.8f, 1)});
			indexBufferPoints->add(static_cast<std::uint32_t>(vertices.size()));

			float sum = 0;

			for (int i = 0; i < samples; i++) {
                vec2 vecField = Integrator::sampleFromField(vr, dims, startPoint);

                if (stopAtZero && vecField.x == 0 && vecField.y == 0) break;

                vec2 curr = 
					Integrator::RK4(vr, dims, startPoint, stepLength, integrationDirection, vecField);
				
				int x1 = curr.x;
                float y1 = curr.y;

                float x2 = startPoint.x;
                float y2 = startPoint.y;
                float distancex = pow(x1 - x2, 2);
                float distancey = pow(y1 - y2, 2);

                if (minVelocity > sqrt(abs(distancex - distancey))) break;

				sum += sqrt(distancex - distancey);

                if (sum > propMaxArcLength.get()) break;

                if (stopAtBoundary && (startPoint.x < 0 || startPoint.x > dims.x - 1 ||
                                       startPoint.y < 0 || startPoint.y > dims.y - 1))
                    break;
                //auto indexBufferRK1 = mesh->addIndexBuffer(DrawType::Lines, ConnectivityType::Strip);

                indexBufferRK->add(static_cast<std::uint32_t>(vertices.size()));

                vertices.push_back(
                    {vec3(startPoint.x / (dims.x - 1), startPoint.y / (dims.y - 1), 0), vec3(3, 4, 1),
                     vec3(5, 120, 140), vec4(0, 0.4f, 0.8f, 1)});

                // LogProcessorInfo("Coord x0: " << startPoint.x << " y0 :" << startPoint.y);
                // LogProcessorInfo("dims : " << dims.x << " y :" << dims.y);
                // Draw line between curr and startPoint

                startPoint = curr;
            }

			std::cout << "Rand" << a + rx << "  ";
        }

        // TODO: Seed multiple stream lines either randomly or using a uniform grid
        // (TODO: Bonus, sample randomly according to magnitude of the vector field)
    }

    mesh->addVertices(vertices);
    outMesh.setData(mesh);
}

void StreamlineIntegrator::drawLineSegmentsByXandY(int dimx, int dimy, const int x, const int y,
                                              inviwo::IndexBufferRAM* indexBufferGrid,
                                              std::vector<inviwo::BasicMesh::Vertex>& vertices) {
    float xCoordSize = dimx / (double)(x - 1);
    float yCoordSize = dimy / (double)(y - 1);
    float delay = 0;
    float yPlanCoord;
    float xPlanCoord;

    for (int i = 0; i < x - 1; i++) {
        for (int j = 0; j < y - 1; j++) {

            xPlanCoord = xCoordSize * i + delay;
            yPlanCoord = yCoordSize * j + delay;

            vec2 v1 = vec2(xPlanCoord, yPlanCoord);
            vec2 v2 = vec2(xPlanCoord + xCoordSize, yPlanCoord);
            vec2 v3 = vec2(xPlanCoord, yPlanCoord + yCoordSize);
            drawLineSegment(v1, v2, vec4(0.0f, 0.0f, 1.0f, 1.0f), indexBufferGrid, vertices);
            drawLineSegment(v1, v3, vec4(0.0f, 0.0f, 1.0f, 1.0f), indexBufferGrid, vertices);
        }
    }

    yPlanCoord = yCoordSize * (y - 1) + delay;
    for (int i = 0; i < x - 1; i++) {
        xPlanCoord = xCoordSize * i + delay;
        vec2 v1 = vec2(xPlanCoord, yPlanCoord);
        vec2 v2 = vec2(xPlanCoord + xCoordSize, yPlanCoord);
        drawLineSegment(v1, v2, vec4(0.0f, 0.0f, 1.0f, 1.0f), indexBufferGrid, vertices);
    }

    xPlanCoord = xCoordSize * (x - 1) + delay;
    for (int j = 0; j < y - 1; j++) {
        yPlanCoord = yCoordSize * j + delay;
        vec2 v1 = vec2(xPlanCoord, yPlanCoord);
        vec2 v2 = vec2(xPlanCoord, yPlanCoord + yCoordSize);
        drawLineSegment(v1, v2, vec4(0.0f, 0.0f, 1.0f, 1.0f), indexBufferGrid, vertices);
    }
}

void StreamlineIntegrator::drawLineSegment(const vec2& v1, const vec2& v2, const vec4& color,
                                      IndexBufferRAM* indexBuffer,
                                      std::vector<BasicMesh::Vertex>& vertices) {
    // Add first vertex
    indexBuffer->add(static_cast<std::uint32_t>(vertices.size()));
    // A vertex has a position, a normal, a texture coordinate and a color
    // we do not use normal or texture coordinate, but still have to specify them
    vertices.push_back({vec3(v1[0], v1[1], 0), vec3(0, 0, 1), vec3(v1[0], v1[1], 0), color});
    // Add second vertex
    indexBuffer->add(static_cast<std::uint32_t>(vertices.size()));
    vertices.push_back({vec3(v2[0], v2[1], 0), vec3(0, 0, 1), vec3(v2[0], v2[1], 0), color});
}

}  // namespace inviwo
